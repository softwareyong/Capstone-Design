from flask import Flask, request
from flask import render_template
import RPi.GPIO as GPIO

LED = 4

app = Flask(__name__)

GPIO.setmode(GPIO.BCM)
GPIO.setup(LED, GPIO.OUT, initial=GPIO.LOW)

@app.route("/")
def home():
    return render_template("index.html") # index.html 문서는 templates 디렉토리 내에 있어야 함

@app.route("/led/on")
def led_on():
    try:
        GPIO.output(LED, GPIO.HIGH)
        return "ok"
    except expression as identifier:
        return "fail"  

@app.route("/led/off")
def led_off():
    try:
        GPIO.output(LED, GPIO.LOW)
        return "ok"
    except expression as identifier:
        return "fail"
        
if __name__ == "__main__":
    app.run(host="0.0.0.0")



