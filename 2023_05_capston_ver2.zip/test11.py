import os

message = "3,3"
command = "mosquitto_pub -h localhost -t testTopic -m {}".format(message)
os.system(command)




# os.system("mosquitto_pub -d -t testTopic -m \"$arr\" ")
# os.system("mosquitto_pub -h localhost -t testTopic -m \"arr\" ")
