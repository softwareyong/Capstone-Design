import paho.mqtt.client as mqtt # paho-MQTT 패키지 불러오기
from flask import Flask, render_template, request, url_for, jsonify
import threading

app = Flask(__name__)
a = 0
message_count = 0

@app.route('/')
def index(message):
    # print(on_message)
    data = {'x': message[0], 'y': message[2]}
                #    3                   3
    # return render_template("index.html", **date)
    return render_template("index.html", **data) # 3,3

# get cooprdinate
@app.route("/cooprdinate")
def get_cooprdinate(message):
    try:
        return jsonify(message)
    except expression as identifier:
        return "fail" 

def start_mqtt_client():
    mqttc = mqtt.Client()
    mqttc.connect('localhost', 1883, 60)
    mqttc.subscribe("testTopic")
    mqttc.on_message = on_message
    # print(mqttc.on_message.payload.decode())
    # print("a:", a)
    # x = mqttc.on_message
    # print(x)
    # print(mqttc.on_message)
    mqttc.loop_forever()
    # mqttc.loop_start()
    
# MQTT 클라이언트 객체에 콜백 함수 정의
def on_message(mqttc, userdata, message):
    global message_count
    message_count += 1
    print(f"수신된 메시지 수: {message_count}")
    get_cooprdinate(str(message.payload.decode()))
    # message = str(message.payload.decode())
    
    # return message
    print("Received message: " + str(message.payload.decode()))
    a = message
    # return message
    
    
# MQTT 클라이언트 객체에 콜백 함수 등록

if __name__ == "__main__":
    # MQTT 클라이언트를 별도의 쓰레드에서 실행
    mqtt_thread = threading.Thread(target=start_mqtt_client)
    mqtt_thread.start()
    
    app.run(debug=True)