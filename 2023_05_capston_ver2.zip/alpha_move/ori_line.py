#!/usr/bin/python
# -*- coding:utf-8 -*-
import cv2
from pyzbar import pyzbar # 바코드 인식
import argparse # 이미지 처리할 때 쓰는거
import imutils # 이미지 처리
import RPi.GPIO as GPIO
from AlphaBot2 import AlphaBot2
from TRSensors import TRSensor
import time

GPIO.setmode(GPIO.BCM)
GPIO.setwarnings(False)

maximum = 20 # 직진 최대 속도
integral = 0
last_proportional = 0

TR = TRSensor()
Ab = AlphaBot2()
# Ab.stop()
print("Line follow Example")
time.sleep(0.5)
for i in range(0,100):
	if(i<25 or i>= 50):
		Ab.right()
		Ab.setPWMA(10)
		Ab.setPWMB(10)
	else:
		Ab.left()
		Ab.setPWMA(10)
		Ab.setPWMB(10)
	TR.calibrate()
Ab.stop()
print(TR.calibratedMin)
print(TR.calibratedMax)

cam = cv2.VideoCapture(-1) # 비디오 켜기
time.sleep(2) # 비디오 켜고 2초 기달리기
# 
Ab.forward() # 앞으로 출발
while True:
    position,Sensors = TR.readLine()

    if(Sensors[0] >900 and Sensors[1] >900 and Sensors[2] >900 and Sensors[3] >900 and Sensors[4] >900):
        Ab.setPWMA(0)
        Ab.setPWMB(0)
    else:
        # The "proportional" term should be 0 when we are on the line.
        proportional = position - 2000
        
        # Compute the derivative (change) and integral (sum) of the position.
        derivative = proportional - last_proportional
        integral += proportional
        
        # Remember the last position.
        last_proportional = proportional


        power_difference = proportional/30  + integral/10000 + derivative*2;  

        if (power_difference > maximum):
            power_difference = maximum
        if (power_difference < - maximum):
            power_difference = - maximum
        # print(position,power_difference)
        if (power_difference < 0):
            Ab.setPWMA(maximum + power_difference)
            Ab.setPWMB(maximum)
        else:
            Ab.setPWMA(maximum)
            Ab.setPWMB(maximum - power_difference)
			
        # 카메라
        ret, frame = cam.read() # 카메라 읽기
        barcodes = pyzbar.decode(frame) # qr코드 추정
        barcodeData = 1 # 바코드데이터 초기화
        
        for barcode in barcodes:
                barcodeData = barcode.data.decode("utf-8")
                        
        if barcodeData == 1:
            pass
        else: 
            result = 0
            while(True):
                start = time.time()
                position,Sensors = TR.readLine()

                if(Sensors[0] >900 and Sensors[1] >900 and Sensors[2] >900 and Sensors[3] >900 and Sensors[4] >900):
                    Ab.setPWMA(0)
                    Ab.setPWMB(0)
                else:
                    # The "proportional" term should be 0 when we are on the line.
                    proportional = position - 2000
                    
                    # Compute the derivative (change) and integral (sum) of the position.
                    derivative = proportional - last_proportional
                    integral += proportional
                    
                    # Remember the last position.
                    last_proportional = proportional

                    power_difference = proportional/30  + integral/10000 + derivative*2;  

                    if (power_difference > maximum):
                        power_difference = maximum
                    if (power_difference < - maximum):
                        power_difference = - maximum
                    # print(position,power_difference)
                    if (power_difference < 0):
                        Ab.setPWMA(maximum + power_difference)
                        Ab.setPWMB(maximum)
                    else:
                        Ab.setPWMA(maximum)
                        Ab.setPWMB(maximum - power_difference)
                    
                    result += time.time() - start
                    print(result)
                    if (result > 0.5):
                        break
            #     os.system("mosquitto_pub -d -t testTopic -m 'f' ")
            # os.system(" mosquitto_pub -h 192.168.137.50 -t test -m \"matrix test\" ")
            Ab.stop()        
            time.sleep(0.5)
            print("left gogo")
            Ab.new_left() # 서버에서 신호주면 이거에 따른 처리 기달리고 가기
            Ab.stop()
            print("coordinate: ", barcodeData, "barcode detect!!!!!!!!")
            cam.release()
            cv2.destroyAllWindows()
            cam = cv2.VideoCapture(-1)
            time.sleep(2) # 카메라 켜지고 2초 기달리기
            Ab.setPWMA(10)
            Ab.setPWMB(10)
            Ab.forward()
                
        k = cv2.waitKey(10) & 0xFF
        if k == 27:
            break
        
cam.release()
cv2.destroyAllWindows()
Ab.stop()
GPIO.cleanup()