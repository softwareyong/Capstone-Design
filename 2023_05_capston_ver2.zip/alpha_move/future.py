#-*-coding:utf-8-*-
import cv2
from pyzbar import pyzbar # 바코드 인식
import argparse # 이미지 처리할 때 쓰는거
import imutils # 이미지 처리
import RPi.GPIO as GPIO
from AlphaBot2 import AlphaBot2
from TRSensors import TRSensor
import time
import os

def start_move(Ab):
    print("Line follow Example")
    Ab.stop()
    print(TR.calibratedMin)
    print(TR.calibratedMax)

def sensor_guess(arr): # 센서값 추정하기
    avg = (1000-arr[0])*0 + (1000-arr[1])*1 + (1000-arr[2])*2 + (1000-arr[3])*3 + (1000-arr[4])*4
    sum = 5000- (arr[0] + arr[1] + arr[2] + arr[3] + arr[4])
    return avg/sum # 추정값 반환

def motor_control(result):
    if result<1: # 스스몰 라이트
        Ab.ssright()
    elif result<1.8: # 스몰 라이트
        Ab.sright()
    elif 1.8<= result and result <=2.2: # 직진
        Ab.forward()
    elif result<3: # 스몰 레프트
        Ab.ssleft()
    else: # 스스몰 레프트
        Ab.sleft()
    Ab.setPWMA(10)
    Ab.setPWMB(10)
# def carlibrate():
    

GPIO.setmode(GPIO.BCM)
GPIO.setwarnings(False) # 워닝 메시지 뜨지않게 한다.

# # 초기화
TR = TRSensor()
Ab = AlphaBot2()
Ab.stop()

# 시작 
start_move(Ab) # 초기화
cam = cv2.VideoCapture(-1) # 비디오 켜기
time.sleep(2) # 비디오 켜고 2초 기달리기
Ab.forward() # 앞으로 출발
pre =  TR.AnalogRead() # 이전센서값 저장

while(True):
    arr = TR.AnalogRead() # 센서값 읽어오기 
    result = sensor_guess(arr) # 센서값을 통한 현재 추정값 가져오기 (1~4)
    print(result)
    motor_control(result) # 추정한 값을 통한 모터제어
    # 칼리브레이트 코드 추가하기

    # 카메라
    ret, frame = cam.read() # 카메라 읽기
    barcodes = pyzbar.decode(frame) # qr코드 추정
    barcodeData = 1 # 바코드데이터 초기화
     
    for barcode in barcodes:
            barcodeData = barcode.data.decode("utf-8")

    k = cv2.waitKey(10) & 0xFF
    if k == 27:
        break
    
    pre = arr
    if barcodeData == 1:
        pass
    else: 
        time.sleep(1)
        # os.system("mosquitto_pub -d -t testTopic -m 'f' ")
        #os.system(" mosquitto_pub -h 192.168.137.50 -t test -m \"matrix test\" ")
        Ab.stop()        
        time.sleep(0.5)
        Ab.rotate_left() # 서버에서 신호주면 이거에 따른 처리 기달리고 가기
        Ab.stop()
        print("coordinate: ", barcodeData, "barcode detect!!!!!!!!")
        cam.release()
        cv2.destroyAllWindows()
        cam = cv2.VideoCapture(-1)
        time.sleep(2) # 카메라 켜지고 2초 기달리기
        Ab.setPWMA(10)
        Ab.setPWMB(10)
        Ab.forward()

cam.release()
cv2.destroyAllWindows()
Ab.stop()
GPIO.cleanup()