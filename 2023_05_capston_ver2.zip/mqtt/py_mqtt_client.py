#-*-coding:utf-8-*-

import paho.mqtt.client as mqtt # paho-MQTT 패키지 불러오기
from flask import Flask, render_template, request # Flask 패키지 불러오기

mqttc = mqtt.Client() # MQTT client 객체 생성, 이거 .server .broker있는지 찾아보기 
app = Flask(__name__) # Flask 웹서버 객체 생성

message = 'NodeMCU LED on'
led = {'name': 'NodeMCU LED pin', 'state': 'ON'}

# Flask 웹서버의 URL 주소로 접근하면 아래의 main()함수를 실행
@app.route('/')
def main():
    mqttc.publish('inTopic', '1') 
    
    templateDate={'message': message, 'led': led}
    return render_template('main.html', **templateDate)

# Flask 웹 서버의 URL주소끝에 <action>를 붙혀서 접근하면 액션 함수 실행
@app.route('/LED/<action>')
def action(action):
    if action == 'on':
        mqttc.publish('inTopic', '1')
        led['state'] = 'ON'
        message = 'ras LED on'
    if action == 'off':
        mqttc.publish('inTopic', '0')
        
        led['state'] = 'OFF'
        message = 'ras LED off'
    
    templateData = {'message': message, 'led':led}
    return render_template('main.html', **templateData)

if __name__ == "__main__":
    mqttc.connect('localhost', 1883, 60)
    mqttc.loop_start()
    app.run(host='0.0.0.0', debug=False)