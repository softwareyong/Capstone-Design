print(" mosquitto_pub -h 192.168.137.50 -t test -m \"fuck me oppa\" ")
